package sample;
/**
 *
 * @author Chris Montani Hints Class is responsible for storing the hints in an array
 * I use this class in the program to sequentially display the hints by array index. They
 * array index is calculated by a global variable in the main class.
 */
public class Hints {
    String[] hintArr = new String[4];
    String hint1, hint2, hint3, hint4;
    
    
    public Hints(){
        hint1 = "If October 7 is either Sarah or turtle, and October 7 does not equal Sarah, then October 7 equals\n"
                + "turtle. Mark the corresponding cell as TRUE. (+30 Second Penalty)";
        
        hint2 = "If Michael is less than pin, then Michael does not equal pin. Mark the \n"
                + "corresponding cell as False. (30 second Penalty)";
        
        hint3 = "If Michael's cake order is delivered before the pin, his cake does not equal \n"
                + "pin. Mark the corresponding square as TRUE for Michael = car. (+30 Second Penalty)";
        
        hint4 = "If Michaels's cake is delivered 1 day after the rocket and Michael's cake equals car, \n"
                + "then Chris's cake must equal rocket. Mark the corresponding square as TRUE for Chris = rocket\n";
        
        hintArr[0] = hint1;
        hintArr[1] = hint2;
        hintArr[2] = hint3;
        hintArr[3] = hint4;
    }

    /**
     * Chris Montani
     * @param counter integer value that will be passed to access the array index
     * @return
     */
    public String getHint(int counter){
        return hintArr[counter].toString();
    }
}
