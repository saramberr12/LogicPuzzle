/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sample;
/**
 *
 * @author Chris Montani Answer class allows the program to make an object of type answer
 * its only job is to get the text of the answer. This class eliminates hard coding directly
 * in the program. This makes the game more flexible and extendable if someone was to work
 * on this in the future.
 */
public class Answer {
    String answer;
    
    public Answer(String answer){
        this.answer = answer;
    }
    
    public String getAnswer(){
        return answer;
    }
    
}
