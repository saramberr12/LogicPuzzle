package sample;

import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.lang.reflect.Array;

import static javafx.application.Platform.exit;


public class Main extends Application {
    /**
     * -Chris Montani - These are all the global variables for the border pane
     * I have broken this class into seperate methods to create each part of the
     * border pane. This makes the class much more readable and effective.
     * Consists of Buttons, Labels, Answer,Clues,Hints,int,Hbox,VBox,BorderPane and Stage.
     */
    Stage window;
    Button start, restart, quit, hint;
    Button notes, answers, clues;
    Label backStory1, backStory2, goal, hint1, hint2, hint3, hint4, hintHeader;
    Label aClue1, aClue2, aClue3, aClue4, aClue5, aClueHeader;
    Label answer1, answer2, answer3, answer4;
    Answer firstAnswer, secondAnswer, thirdAnswer, fourthAnswer;
    Clues clue0,clue1, clue2, clue3, clue4, clue5;
    Label textNotes;
    Label hintText;
    Hints hintArr;
    int count = 0;
    int hour = 0, minute = 0, second = 0, semisecond = 0;
    HBox bottomHints = new HBox();
    BorderPane pane = new BorderPane();
    VBox notesBox = new VBox();
    VBox clueBox = new VBox();
    VBox answerBox = new VBox();
    Stage stage = new Stage();
    @Override
    /**
     * -Chris Montani Start method is what initiates the program, I call the below method
     * in start. This makes for more readable and organized code. Each method in start is
     * responsible for placing a different pane on top of the border pane.
     */

    public void start(Stage primaryStage) throws Exception{

        createTopToolBar();
        createBackStoryBox();
        createClueBox();
        createAnswerBox();
        createNotesBox();
        createHintBox();
        createGrid();


        Scene scene = new Scene(pane, 1350, 700);
        scene.getStylesheets().add("PuzzleCSS.css");
        stage.setTitle("Logic Puzzle Game");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * -Chris Montani createTopToolBar() method is what creates the buttons located
     * on the top of the program (Hint, Quit, Notes, Answers, Clues) I have used an HBox
     * because this lays out the buttons one after the other although I hard code their
     * location in the window with translateX().
     */

    public void createTopToolBar(){

        HBox topToolBar = new HBox();
        topToolBar.setPadding(new Insets(20));
      //  topToolBar.setAlignment(Pos.TOP_CENTER);

        //start = new Button("Start");
        //start.setTranslateX(600);

       // restart = new Button("Restart");
       // restart.setTranslateX(650);

        quit = new Button("Quit");
        quit.setTranslateX(200);

        hint = new Button("Hint");
        hint.setTranslateX(250);

        answers = new Button("Answers");
        answers.setTranslateX(400);

        notes = new Button("Notes");
        notes.setTranslateX(550);

        clues = new Button("Clues");
        clues.setTranslateX(680);

        topToolBar.getChildren().addAll( quit, hint, clues,notes,answers);
        pane.setTop(topToolBar);
    }

    /**
     * -Chris Montani createBackStoryBox() is responsible for displaying the directions on
     * the left hand side of the program. I have hardcoded the directions because these
     * directions will never change. I decided to use a VBox because it allocates space and
     * places controls on top of each other. I also set its style to a CSS style sheet that
     * I have created.
     */

    public void createBackStoryBox(){
        VBox leftBox = new VBox();
        leftBox.setPadding(new Insets(10,10,10,10));

        backStory1 = new Label("     Diana's Specialty Cakes has a \t\n     number of different cake order \n     to fulfill"
                + "this week. Using only the    \n     clues that follow, match each   \n     customer to their"
                + "specialty cake's   \n     shape, and determine the day \n     each cake is to be delivered.  \n "
                + "\n     Remember, as with all grid-based    \n     logic puzzles, no option in any   \n" +
                "     category will ever be used more   \n     than once. If you get stuck or   \n" +
                "     run into problems, try the    \n     'Hint' button to  see the next  \n" +
                "     logical step in the puzzle.   \n\n");
        backStory1.getStyleClass().add("label-backStory1");



        goal = new Label("        Backstory And Goal");
        goal.getStyleClass().add("label-backStoryHeader");
        leftBox.getChildren().addAll(goal,backStory1);
        leftBox.setTranslateX(30);
        pane.setLeft(leftBox);
    }

    /**
     * -Chris Montani createClueBox() is responsible for displaying the clues on the right
     * hand side of the window. I created a Clues class so if someone wanted to make a different
     * logic puzzle game they dont need to hard code directly to the program but instead can
     * create a clue object and set that object to the text of a label.
     * -Chris Montani I have added onAction events in this class so whenever a button is
     * clicked the rightpane of the border pane will display the clues when the "Clues' button
     * is pressed.
     */

    public void createClueBox() {

        clueBox.setPadding(new Insets(10,10,10,10));

        clue0 = new Clues("\t\t\t   Clues");
        aClueHeader = new Label(clue0.getText());
        aClueHeader.getStyleClass().add("label-hintText");
        clue1 = new Clues("\n1.) Chris's cake will be in the shape\n     of a rocket.");
        aClue1 = new Label(clue1.getText());
        aClue1.getStyleClass().add("label-hintText");
        clue2 = new Clues("\n2.) Bradley's cake will be delivered on\n     October 7th.");
        aClue2 = new Label(clue2.getText());
        aClue2.getStyleClass().add("label-hintText");
        clue3 = new Clues("\n3.) The October 7 delivery is either\n     Sarah's cake or the cake shaped\n     like a turtle.");
        aClue3 = new Label(clue3.getText());
        aClue3.getStyleClass().add("label-hintText");
        clue4 = new Clues("\n4.) Michael's cake order will be\n     delivered 1 day after Chris's\n     cake order.");
        aClue4 = new Label(clue4.getText());
        aClue4.getStyleClass().add("label-hintText");
        clue5 = new Clues("\n5.) Michael's cake order will be\n     delivered sometime before the\n     cake order shaped like a pin.");
        aClue5 = new Label(clue5.getText());
        aClue5.getStyleClass().add("label-hintText");

        clueBox.getChildren().addAll(aClueHeader, aClue1, aClue2, aClue3, aClue4, aClue5);
        pane.setRight(clueBox);
        notes.setOnAction(e -> pane.setRight(notesBox));
        answers.setOnAction(e -> pane.setRight(answerBox));


    }

    /**
     * -Chris Montani
     * createNotesBox() is responsible for creating the textArea where the user can enter
     * notes to help them solve the puzzle. This TextArea will save the text when the rightpane
     * of the borderpane has changed. I have also added onActionEvents here.
     */
    public void createNotesBox(){

        notesBox.setPadding(new Insets(10,10,10,10));

        TextArea notesField = new TextArea();
        notesField.setPrefSize(300, 150);
        notesField.setWrapText(true);
        notesField.setTranslateX(-150);

        textNotes = new Label("Enter Your Personal Notes Here!\n\n");
        textNotes.setTranslateX(-145);
        textNotes.getStyleClass().add("label-textNotes");

        notesBox.getChildren().addAll(textNotes,notesField);
        pane.setRight(notesBox);
        notes.setOnAction(e -> pane.setRight(notesBox));
        clues.setOnAction(e -> pane.setRight(clueBox));
        answers.setOnAction(e -> pane.setRight(answerBox));

    }

    /**
     * -Chris Montani
     * createAnswerBox() is responsible for displaying the VBox  which holds the answers
     * if the user cannot figure the puzzle out. Located on the right side of the BorderPane
     *
     */


    public void createAnswerBox(){

        answerBox.setPadding(new Insets(10,10,10,10));

        firstAnswer = new Answer("\n\n\nBradley -> October 7 -> Turtle  ");
        answer1 = new Label(firstAnswer.getAnswer());
        answer1.getStyleClass().add("label-answerText");
        secondAnswer = new Answer("\nMichael -> October 6 -> Boat");
        answer2 = new Label(secondAnswer.getAnswer());
        answer2.getStyleClass().add("label-answerText");
        thirdAnswer = new Answer("\nChris -> October 5 -> Rocket");
        answer3 = new Label(thirdAnswer.getAnswer());
        answer3.getStyleClass().add("label-answerText");
        fourthAnswer = new Answer("\nSarah -> October 8 -> Pin");
        answer4 = new Label(fourthAnswer.getAnswer());
        answer4.getStyleClass().add("label-answerText");

        answerBox.getChildren().addAll(answer1, answer2, answer3, answer4);
        pane.setRight(answerBox);
        answers.setOnAction(e -> pane.setRight(answerBox));
        quit.setOnAction(e -> exit());

    }

    /**
     * -Chris Montani
     * createHintBox()  sets the bottom pane of BorderPane to a HBox and I create an instance
     * of the Hints class I created. This class allows me to make an object of hints which are
     * of type string I store these hints in an array and I use a global count variable to access
     * the correct index of the hint and I display the hint that corrosponds with the value of
     * the global count variable. If count is > 3 I set the count to 0 because the array only
     * holds 4 elements.
     */

    public void createHintBox(){

        bottomHints.setPadding(new Insets(10,10,10,10));
        bottomHints.setAlignment(Pos.CENTER);

        hintArr = new Hints();
        hintText = new Label("");
        hint.setOnAction(e ->{

            hintText.setText(hintArr.getHint(count));
            hintText.getStyleClass().add("label-answerText");

            pane.setBottom(bottomHints);
            count++;
            if (count > 3){
                count = 0;
            }

        });
        bottomHints.getChildren().addAll(hintText);


    }

    /**
     * -Chris Montani
     * The createGrid() class is responsible for displaying the actual game grid in the center
     * of the BorderPane. I have stored the categories in arrays which I then use a for loop to
     * display all the names, cakes, and dates in the correct column and row. In order to display
     * the grid correctly I had to set constraints to the buttons in the bottom right of the grid.
     * I did this by simply setting the buttons visibility to false. Once the for loop hits the
     * particular condition of the column and row constraints buttons will no longer be visible
     *
     * -Chris Montani
     * I have used setOnMousePressed() to keep track of how many times the mouse has been clicked
     * This allows me to set the text of a button to an 'X" and 'O" on single or double click
     * of the mouse
     */

    public void createGrid(){
        GridPane pane1 = new GridPane();
        pane1.setVgap(6);
        pane1.setHgap(6);

        String[] icon = new String[3];
        icon[0] = "X";
        icon[1] = "O";
        icon[2] = " ";

        Label[] names = new Label[9];
        names[0] = new Label("     ");
        names[1] = new Label(" Sarah");
        names[2] = new Label(" Chris");
        names[3] = new Label("Michael");
        names[4] = new Label( "  Brad");
        names[5] = new Label("Rocket");
        names[6] = new Label(" Turtle");
        names[7] = new Label("   Car");
        names[8] = new Label("   Pin");


        Label[] dates = new Label[9];
        dates[0] = new Label("      ");
        dates[1] = new Label("Oct. 5");
        dates[2] = new Label("Oct. 6");
        dates[3] = new Label("Oct. 7");
        dates[4] = new Label("Oct. 8");
        dates[5] = new Label("Rocket");
        dates[6] = new Label("Turtle");
        dates[7] = new Label("Car");
        dates[8] = new Label("Pin");


        for(int i = 0; i < 9; i++) {
            pane1.getColumnConstraints().add(new ColumnConstraints(50));
            if(i > 0) {
                Label label = names[i];
                pane1.add(label, i, 0);
                //pane1.getChildren().add(label);
            }

            /*
            Button[] arrayOfButtons = new Button[64];
            for (int j = 0; j <= arrayOfButtons.length; j++) {
                arrayOfButtons[j] = new Button();
            } */


            if (i >0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                if (button.getText().equals("O")){
                    //pane1.get();
                }
                pane1.add(button,i,1);
            }
            if (i > 0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            button.setId("2");
                            button.getId();
                            System.out.println(button.getId());
                            button.getLayoutX();
                            button.getLayoutY();
                            System.out.println(button.getLayoutX());
                            System.out.println(button.getLayoutY());
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                pane1.add(button,i,2);
            }
            if (i > 0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            button.setId("3");
                            button.getId();
                            System.out.println(button.getId());
                            button.getLayoutX();
                            button.getLayoutY();
                            System.out.println(button.getLayoutX());
                            System.out.println(button.getLayoutY());
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                pane1.add(button,i,3);
            }
            if (i > 0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            button.setId("4");
                            button.getId();
                            System.out.println(button.getId());
                            button.getLayoutX();
                            button.getLayoutY();
                            System.out.println(button.getLayoutX());
                            System.out.println(button.getLayoutY());
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                pane1.add(button,i,4);
            }
            if (i > 0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            button.setId("5");
                            button.getId();
                            System.out.println(button.getId());
                            button.getLayoutX();
                            button.getLayoutY();
                            System.out.println(button.getLayoutX());
                            System.out.println(button.getLayoutY());
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                pane1.add(button,i,5);
                if (i>4){
                    button.setVisible(false);
                }

            }
            if (i > 0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            button.setId("6");
                            button.getId();
                            System.out.println(button.getId());
                            button.getLayoutX();
                            button.getLayoutY();
                            System.out.println(button.getLayoutX());
                            System.out.println(button.getLayoutY());
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                pane1.add(button,i,6);
                if (i>4){
                    button.setVisible(false);
                }
            }
            if (i > 0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            button.setId("7");
                            button.getId();
                            System.out.println(button.getId());
                            button.getLayoutX();
                            button.getLayoutY();
                            System.out.println(button.getLayoutX());
                            System.out.println(button.getLayoutY());
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                pane1.add(button,i,7);
                if (i>4){
                    button.setVisible(false);
                }
            }
            if (i > 0){
                Button button = new Button();
                button.setStyle("-fx-background-color: white");
                button.setPrefSize(50,50);
                button.setOnMousePressed(e ->{
                    switch(e.getClickCount()){
                        case 1:
                            button.setText("X");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 25px");
                            break;
                        case 2:
                            button.setText("O");
                            button.setStyle("-fx-background-color: white; -fx-text-fill: green; -fx-font-weight: bold; -fx-font-size: 25px");
                            button.setId("8");
                            button.getId();
                            System.out.println(button.getId());
                            button.getLayoutX();
                            button.getLayoutY();
                            System.out.println(button.getLayoutX());
                            System.out.println(button.getLayoutY());
                            break;
                        case 3:
                            button.setText("");
                            break;
                    }
                });
                pane1.add(button,i,8);
                if (i>4){
                    button.setVisible(false);
                }
            }

        }



        for(int i = 0; i <9; i++){
            pane1.getColumnConstraints().add(new ColumnConstraints(100));
            if(i>0){
                Label label = dates[i];
                pane1.add(label,0,i);
            }
        }

        pane1.setTranslateX(350);
        pane1.setTranslateY(50);
        pane.setCenter(pane1);
    }




    public static void main(String[] args) {
        launch(args);
    }
}
