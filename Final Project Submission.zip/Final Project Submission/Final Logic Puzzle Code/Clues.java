package sample;

/**
 *
 * @author Chris Montani Clues class is very similar to answer class the main purpose
 * of this class is to reduce hardcoding and make the program more efficiten and more
 * extendable. A developer can make a different version of this game with different Clues
 */
public class Clues {
    String clue;
    
    public Clues(String clue){
        this.clue = clue;
    }
    
    public String getText(){
        return clue;
    }
}
